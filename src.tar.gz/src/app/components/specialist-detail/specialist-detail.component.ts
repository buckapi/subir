import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-specialist-detail',
  standalone: true,
  imports: [],
  templateUrl: './specialist-detail.component.html',
  styleUrl: './specialist-detail.component.css',
  encapsulation: ViewEncapsulation.Emulated 
})
export class SpecialistDetailComponent {

}
