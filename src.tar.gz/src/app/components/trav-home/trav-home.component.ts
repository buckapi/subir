import { Component } from '@angular/core';

@Component({
  selector: 'app-trav-home',
  standalone: true,
  imports: [],
  templateUrl: './trav-home.component.html',
  styleUrl: './trav-home.component.css'
})
export class TravHomeComponent {

}
