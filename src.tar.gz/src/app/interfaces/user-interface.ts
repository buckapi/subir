export interface UserInterface{
	id?:string;
	name?:string;
	avatar?:string;
	email?:string;
	password?:string;
	type?:string;
	status?:string;
	usertype?:string;
}