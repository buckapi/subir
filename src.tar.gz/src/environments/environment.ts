export const environment = {
    production: true,
    apiUrl: 'https://db.buckapi.com:8990'
};

